package sisal.accademy.books;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AuthorController {
	
	@Autowired
	AuthorRepository repository;

	@GetMapping("/createauthor")
	public String createAuthor() {
		return "createauthor";	
	}

	@GetMapping("/addauthor")
	public String addAuthor(
			@RequestParam(name="name",required=true)
			String name,
			@RequestParam(name="secondname",required=true)
			String secondname,
			Model model) {
		
		Author author=new Author(name, secondname);
		repository.save(author);
		
		model.addAttribute("text","Autore creato correttamente");
		model.addAttribute("backlink","/createauthor");
		model.addAttribute("backtext","Ritorna alla pagina di Creazione dell'Autore");
		
		return "confirm";
	}
}
