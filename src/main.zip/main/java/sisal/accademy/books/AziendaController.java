package sisal.accademy.books;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;




@Controller
public class AziendaController {
	
	@Autowired
	AziendaRepository repository;
	
	
	@GetMapping("/createazienda")
	public String createAzienda() {
		return "createazienda";
	}
	
	@GetMapping("/addazienda")
	public String addAzienda(@RequestParam(name="nome",required=true) String nome, 
			@RequestParam(name="sede",required=true)String sede, @RequestParam(name="dataFondazione",required=true)String dataFondazione,
			@RequestParam(name="settore",required=true)String settore,@RequestParam(name="info",required=true)String info,
			Model model) {
		
		Azienda azienda = new Azienda(nome,sede,dataFondazione,settore,info);
		repository.save(azienda);
		
		model.addAttribute("text","Azienda creata correttamente");
		model.addAttribute("backlink","/");
		model.addAttribute("backtext","Ritorna alla pagina delle aziende");
		
		return "confirm";
	}
	
	@GetMapping("/")
	public String aziende(Model model) {
		

		Iterable<Azienda> aziende = repository.findAll();
		model.addAttribute("aziende", aziende);
		model.addAttribute("title", "Aziende");
		
		
		
		
		return "aziende";
	}
	
	
	
	
}
