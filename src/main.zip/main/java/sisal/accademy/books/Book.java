package sisal.accademy.books;

import java.util.List; 

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
 

 
@Entity
public class Book {

	@Id
	private int id;

	private String title;
	private Genre genre;
	private int year;
	private String publisher;
	
	@ManyToOne
	private Author mainAuthor;
	
	@ManyToMany
	private List<Author> otherAuthors;
	

	/*Indispensabile per il funzionamento di JPA:
	 * costruttore protetto di default che non fa niente.
	 * 
	 * Quando JPA costruisce un oggetto usando i dati che arrivano dal DB:
	 *   - chiama questo costruttore
	 *   - chiama tutti i metodi set
	 * 
	 * */
	protected Book() {
		
	}
	


	public Book(String title, Genre genre, int year, String publisher, Author mainAuthor,
			List<Author> otherAuthors) { 
		this.title = title;
		this.genre = genre;
		this.year = year;
		this.publisher = publisher;
		this.mainAuthor = mainAuthor;
		this.otherAuthors = otherAuthors;
	}


	public Book(int id, String title, Genre genre, int year, String publisher, Author mainAuthor,
			List<Author> otherAuthors) { 
		this.id = id;
		this.title = title;
		this.genre = genre;
		this.year = year;
		this.publisher = publisher;
		this.mainAuthor = mainAuthor;
		this.otherAuthors = otherAuthors;
	}



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Genre getGenre() {
		return genre;
	}

	public void setGenre(Genre genre) {
		this.genre = genre;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	
	

	public Author getMainAuthor() {
		return mainAuthor;
	}

	public void setMainAuthor(Author mainAuthor) {
		this.mainAuthor = mainAuthor;
	}

	public List<Author> getOtherAuthors() {
		return otherAuthors;
	}

	public void setOtherAuthors(List<Author> otherAuthors) {
		this.otherAuthors = otherAuthors;
	}

	@Override
	public String toString() {
		return super.toString();
	}
}
