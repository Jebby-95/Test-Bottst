package sisal.accademy.books;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Books11Application {

	public static void main(String[] args) {
		SpringApplication.run(Books11Application.class, args);
	}

}
