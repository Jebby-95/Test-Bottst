package sisal.accademy.books;

public enum Genre {
	ROMANZO,
	NARRATIVA,
	AZIONE
}
